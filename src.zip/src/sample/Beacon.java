package sample;

public class Beacon extends Object {
    public Beacon(int x, int y) {
        super(x, y);
    }
}
