package sample;

public class Pit extends Object{
    public Pit(int x, int y) {
        super(x, y);
    }
}
