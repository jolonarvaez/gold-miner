package sample;

public class Gold extends Object {
    public Gold(int x, int y) {
        super(x, y);
    }
}
